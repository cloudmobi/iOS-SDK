//
//  NativeVideoTableViewCell.m
//  CTSDK_iOS
//
//  Created by yeahmobi on 2018/3/9.
//  Copyright © 2018年 Mirinda. All rights reserved.
//

#import "NativeVideoMediaViewTableViewCell.h"
#import <CTSDK/CTSDK.h>
@interface NativeVideoMediaViewTableViewCell()
@property (nonatomic, strong)UITapGestureRecognizer *downloadGesture;
@property (nonatomic, strong)UITapGestureRecognizer *jumpGesture;
@property (nonatomic, strong)UITapGestureRecognizer *jumpGesture1;
@end

@implementation NativeVideoMediaViewTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)addClickGesture{
    //download button click
    self.downloadGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickDownload)];
    [self.nvBtnView addGestureRecognizer:self.downloadGesture];
    
    //click gesture添加到希望响应事件的ui上
    self.jumpGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickAD)];
    self.jumpGesture.numberOfTapsRequired = 1;
    self.jumpGesture.numberOfTouchesRequired = 1;
    [self.model.videoViewController.view addGestureRecognizer:self.jumpGesture];
    
    self.jumpGesture1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickAD)];
    self.jumpGesture1.numberOfTapsRequired = 1;
    self.jumpGesture1.numberOfTouchesRequired = 1;
    self.nvBg.userInteractionEnabled = YES;
    [self.nvBg addGestureRecognizer:self.jumpGesture1];
}

- (void)clickAD{
    //navigator push
//    [self.model clickToPushOnParentVC:self.tableViewController animated:YES];
    [self.model clickToPresentOnParentVC:self.tableViewController animated:YES completion:nil];
}
- (void)clickDownload{
    [self.model clickDownload];
}

- (void)dealloc{
    [self.nvBtnView removeGestureRecognizer:self.downloadGesture];
    [self.model.videoViewController.view removeGestureRecognizer:self.jumpGesture];
    [self.nvBg removeGestureRecognizer:self.jumpGesture1];
}
@end
