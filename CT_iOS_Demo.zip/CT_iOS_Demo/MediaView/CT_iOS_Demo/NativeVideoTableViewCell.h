//
//  NativeVideoTableViewCell.h
//  CTSDK_iOS
//
//  Created by yeahmobi on 2018/3/9.
//  Copyright © 2018年 Mirinda. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CTSDK/CTSDK.h>

@interface NativeVideoTableViewCell : UITableViewCell
@property (nonatomic, strong)CTMediaView *mediaView;
@property (nonatomic, strong)UILabel *nvTitleLable;
@property (nonatomic, strong)UILabel* nvDescLable;
@property (nonatomic, strong)UIImageView *nvLogo;
@property (nonatomic, strong)UIImageView *nvBg;
@property (nonatomic, strong)UIButton *nvBtnView;
@property (nonatomic, strong)UIImageView *playLogo;
@property (nonatomic, strong)UILabel *nvErrorLabel;
@property (nonatomic, strong)CTNativeVideoModel *model;             //广告数据模型
@property (nonatomic, weak)UIViewController *tableViewController;   //推出商店需要使用父vc
@property (nonatomic, assign)BOOL isShowed;         //用于标记cell已展示，可播放视频

-(void)addClickGesture;
@end
