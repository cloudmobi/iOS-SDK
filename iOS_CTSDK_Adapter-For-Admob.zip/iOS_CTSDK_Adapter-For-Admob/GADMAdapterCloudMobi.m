//
//  GADMAdapterCloudMobi.m
//  GPADMOB
//
//  Created by 兰旭平 on 2017/11/10.
//  Copyright © 2017年 MySDK.com. All rights reserved.
//

#import "GADMAdapterCloudMobi.h"
#import <CTSDK/CTSDK.h>
@import GoogleMobileAds;

@interface GADMAdapterCloudMobi () <GADMRewardBasedVideoAdNetworkAdapter,CTRewardVideoDelegate>
{
    __weak id<GADMRewardBasedVideoAdNetworkConnector> _rewardBasedVideoAdConnector;
}
@property NSString *slotID;
@end

@implementation GADMAdapterCloudMobi

+ (NSString *)adapterVersion
{
    return [[CTService shareManager] getSDKVersion];
}

- (instancetype)initWithRewardBasedVideoAdNetworkConnector:(id<GADMRewardBasedVideoAdNetworkConnector>)connector {
    if (!connector) {
        return nil;
    }
    
    self = [super init];
    if (self) {
        _rewardBasedVideoAdConnector = connector;
        NSDictionary *credentials = [connector credentials];
        self.slotID = credentials[@"parameter"];
        [[CTService shareManager] loadRequestGetCTSDKConfigBySlot_id:self.slotID];
    }
    return self;
}
- (void)setUp
{
    if (self.slotID) {
        [[CTService shareManager] loadRequestGetCTSDKConfigBySlot_id:self.slotID];
        [_rewardBasedVideoAdConnector adapterDidSetUpRewardBasedVideoAd:self];
    } else {
        NSError *error = [NSError errorWithDomain:kGADErrorDomain
                                             code:kGADErrorMediationAdapterError
                                         userInfo:@{NSLocalizedDescriptionKey:
                                                        @"Adapter not initialized,Because CT SLOTID is nil!"}];
        [_rewardBasedVideoAdConnector adapter:self didFailToSetUpRewardBasedVideoAdWithError:error];
    }
}

- (void)requestRewardBasedVideoAd
{
    [[CTService shareManager] loadRewardVideoWithSlotId:self.slotID delegate:self finishPageIsVertical:YES];
}

- (void)presentRewardBasedVideoAdWithRootViewController:(UIViewController *)viewController
{
    [[CTService shareManager] showRewardVideoWithPresentingViewController:viewController];
}

+ (Class<GADAdNetworkExtras>)networkExtrasClass {
    return nil;
}

- (void)stopBeingDelegate {
    
}

#pragma mark - CTSDK DELEGATE

- (void)CTRewardVideoLoadSuccess
{
    [_rewardBasedVideoAdConnector adapterDidReceiveRewardBasedVideoAd:self];
}

- (void)CTRewardVideoDidStartPlaying
{
    [_rewardBasedVideoAdConnector adapterDidStartPlayingRewardBasedVideoAd:self];
    [_rewardBasedVideoAdConnector adapterDidOpenRewardBasedVideoAd:self];
}

- (void)CTRewardVideoDidFinishPlaying
{
    NSLog(@"CTRewardVideoDidFinishPlaying");
}

- (void)CTRewardVideoDidClickRewardAd
{
    [_rewardBasedVideoAdConnector adapterDidGetAdClick:self];
}

- (void)CTRewardVideoWillLeaveApplication
{
    [_rewardBasedVideoAdConnector adapterWillLeaveApplication:self];
}

- (void)CTRewardVideoJumpfailed
{
    NSLog(@"CTRewardVideoJumpfailed");
}

- (void)CTRewardVideoLoadingFailed:(NSError *)error
{
    [_rewardBasedVideoAdConnector adapter:self didFailToLoadRewardBasedVideoAdwithError:error];
}

- (void)CTRewardVideoClosed
{
    [_rewardBasedVideoAdConnector adapterDidCloseRewardBasedVideoAd:self];
}

- (void)CTRewardVideoAdRewardedName:(NSString *)rewardName rewardAmount:(NSString *)rewardAmount
{
    GADAdReward *reward = [[GADAdReward alloc] initWithRewardType:rewardName
                                                     rewardAmount:[NSDecimalNumber decimalNumberWithString:rewardAmount]];
    [_rewardBasedVideoAdConnector adapter:self didRewardUserWithReward:reward];
}

@end
