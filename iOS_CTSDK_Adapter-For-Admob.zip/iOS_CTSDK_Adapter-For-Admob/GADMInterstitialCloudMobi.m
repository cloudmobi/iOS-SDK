//
//  GADMInterstitialCloudMobi.m
//  GPADMOB
//
//  Created by 兰旭平 on 2017/11/14.
//  Copyright © 2017年 MySDK.com. All rights reserved.
//

#import "GADMInterstitialCloudMobi.h"
#import <CTSDK/CTSDK.h>
@import GoogleMobileAds;
@interface GADMInterstitialCloudMobi () <GADCustomEventInterstitial>

@end

@implementation GADMInterstitialCloudMobi

#pragma mark GADCustomEventInterstitial implementation
@synthesize delegate;
- (void)requestInterstitialAdWithParameter:(NSString *)serverParameter
                                     label:(NSString *)serverLabel
                                   request:(GADCustomEventRequest *)request {
    NSLog(@"request cloudmobi interstitial:%@ %@ ",serverParameter,serverLabel);
    [[CTService shareManager] loadRequestGetCTSDKConfigBySlot_id:serverParameter];
    [[CTService shareManager] preloadMRAIDInterstitialAdWithSlotId:serverParameter delegate:self isTest:YES];
}

/// Present the interstitial ad as a modal view using the provided view controller.
- (void)presentFromRootViewController:(UIViewController *)rootViewController {
    if ([[CTService shareManager] mraidInterstitialIsReady]) {
        [[CTService shareManager] mraidInterstitialShow];
    }
}

#pragma mark - Delegate

- (void)CTAdViewDidRecieveInterstitialAd {
    NSLog(@"cloudmobi interstitial : ok");
    [self.delegate customEventInterstitialDidReceiveAd:self];
}

- (void)CTAdView:(CTADMRAIDView *)adView didFailToReceiveAdWithError:(NSError *)error {
    NSLog(@"cloudmobi interstitial : error %@",error);
    [self.delegate customEventInterstitial:self didFailAd:error];
}

- (BOOL)CTAdView:(CTADMRAIDView*)adView shouldOpenURL:(NSURL*)url {
    [self.delegate customEventInterstitialWasClicked:self];
    return YES;
}

- (void)CTAdViewWillLeaveApplication:(CTADMRAIDView*)adView {
    [self.delegate customEventInterstitialWillPresent:self];
    [self.delegate customEventInterstitialWillLeaveApplication:self];
}

//did click close button
- (void)CTAdViewCloseButtonPressed:(CTADMRAIDView*)adView {
    [self.delegate customEventInterstitialWillDismiss:self];
}

@end
