//
//  ViewController.m
//  CT_iOS_Demo
//
//  Created by 兰旭平 on 2017/12/6.
//  Copyright © 2017年 MySDK.com. All rights reserved.
//

#import "ViewController.h"
#import <CTSDK/CTSDK.h>
#import "BannerViewController.h"
#import "InterstitialViewController.h"
#import "CTNativeViewController.h"
#import "AppWallViewController.h"
#import "RewardVideoViewController.h"
#import "Tools.h"
#import "NativeVideoViewController.h"
#import "NativeVideoMediaViewController.h"

static const int num = 7;
static int i = 0;

@interface ViewController () <CTRewardVideoDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self setBannerClick];
    [self setInterstitialClick];
    [self setNativeClick];
    [self setAppWallClick];
    [self setRewardVideoClick];
    [self setNativeVideoClick];
    [self setNativeVideoMediaView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setBannerClick
{
    UIButton *tagButton = [UIButton buttonWithType:UIButtonTypeCustom];
    tagButton.frame = CGRectMake(0, kScreenHeight / num * i ++, kScreenWidth, kScreenHeight / num);
    tagButton.tag = 100;
    [tagButton setTitle:@"Banner" forState:UIControlStateNormal];
    tagButton.backgroundColor = [UIColor redColor];
    [tagButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:tagButton];
}

- (void)setInterstitialClick
{
    UIButton *tagButton = [UIButton buttonWithType:UIButtonTypeCustom];
    tagButton.frame = CGRectMake(0, kScreenHeight / num * i ++, kScreenWidth, kScreenHeight / num);
    tagButton.tag = 200;
    [tagButton setTitle:@"Interstitial" forState:UIControlStateNormal];
    tagButton.backgroundColor = [UIColor grayColor];
    [tagButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:tagButton];
}

- (void)setNativeVideoMediaView
{
    UIButton *tagButton = [UIButton buttonWithType:UIButtonTypeCustom];
    tagButton.frame = CGRectMake(0, kScreenHeight / num * i ++, kScreenWidth, kScreenHeight / num);
    tagButton.tag = 700;
    [tagButton setTitle:@"Native Video(MediaView)" forState:UIControlStateNormal];
    tagButton.backgroundColor = [UIColor blueColor];
    [tagButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:tagButton];
}

- (void)setNativeClick
{
    UIButton *tagButton = [UIButton buttonWithType:UIButtonTypeCustom];
    tagButton.frame = CGRectMake(0, kScreenHeight / num * i ++, kScreenWidth, kScreenHeight / num);
    tagButton.tag = 300;
    [tagButton setTitle:@"Native" forState:UIControlStateNormal];
    tagButton.backgroundColor = [UIColor cyanColor];
    [tagButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:tagButton];
}

- (void)setAppWallClick
{
    UIButton *tagButton = [UIButton buttonWithType:UIButtonTypeCustom];
    tagButton.frame = CGRectMake(0, kScreenHeight / num * i ++, kScreenWidth, kScreenHeight / num);
    tagButton.tag = 400;
    [tagButton setTitle:@"AppWall" forState:UIControlStateNormal];
    tagButton.backgroundColor = [UIColor grayColor];
    [tagButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:tagButton];
}

- (void)setRewardVideoClick
{
    UIButton *tagButton = [UIButton buttonWithType:UIButtonTypeCustom];
    tagButton.frame = CGRectMake(0, kScreenHeight / num * i ++, kScreenWidth, kScreenHeight / num);
    tagButton.tag = 500;
    [tagButton setTitle:@"RewardVideo" forState:UIControlStateNormal];
    tagButton.backgroundColor = [UIColor orangeColor];
    [tagButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:tagButton];
}

- (void)setNativeVideoClick
{
    UIButton *tagButton = [UIButton buttonWithType:UIButtonTypeCustom];
    tagButton.frame = CGRectMake(0, kScreenHeight / num * i ++, kScreenWidth, kScreenHeight / num);
    tagButton.tag = 600;
    [tagButton setTitle:@"NativeVideo" forState:UIControlStateNormal];
    tagButton.backgroundColor = [UIColor yellowColor];
    [tagButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:tagButton];
}

- (void)clickButton:(id)sender
{
    UIButton *button = (UIButton *)sender;
    switch (button.tag) {
        case 100:
            [self presentViewController:[[BannerViewController alloc] init] animated:YES completion:nil];
            break;
        case 200:
            [self presentViewController:[[InterstitialViewController alloc] init] animated:YES completion:nil];
            break;
        case 300:
            [self presentViewController:[[CTNativeViewController alloc] init] animated:YES completion:nil];
            break;
        case 400:
            [self presentViewController:[[AppWallViewController alloc] init] animated:YES completion:nil];
            break;
        case 500:
            [self presentViewController:[[RewardVideoViewController alloc] init] animated:YES completion:nil];
            break;
        case 600:
            [self presentViewController:[[NativeVideoViewController alloc] init] animated:YES completion:nil];
            break;
        case 700:
            [self presentViewController:[[NativeVideoMediaViewController alloc] init] animated:YES completion:nil];
            break;
        default:
            break;
    }
}
@end
