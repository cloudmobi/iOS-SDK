//
//  MPAdConfiguration+Testing.m
//  MoPubSDK
//
//  Copyright © 2017 MoPub. All rights reserved.
//

#import "MPAdConfiguration+Testing.h"

@implementation MPAdConfiguration (Testing)

@dynamic clickthroughExperimentBrowserAgent;

@end
