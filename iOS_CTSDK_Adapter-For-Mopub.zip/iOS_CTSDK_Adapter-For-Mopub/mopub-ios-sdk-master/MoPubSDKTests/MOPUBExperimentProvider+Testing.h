//
//  MOPUBExperimentProvider+Testing.h
//  MoPubSDK
//
//  Copyright © 2017 MoPub. All rights reserved.
//

#import "MOPUBExperimentProvider.h"

@interface MOPUBExperimentProvider (Testing)

+ (void)setDisplayAgentOverriddenByClientFlag:(BOOL)flag;

@end
