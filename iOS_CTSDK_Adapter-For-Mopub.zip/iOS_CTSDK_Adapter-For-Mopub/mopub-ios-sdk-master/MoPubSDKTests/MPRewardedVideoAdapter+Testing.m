//
//  MPRewardedVideoAdapter+Testing.m
//  MoPubSDK
//
//  Copyright © 2017 MoPub. All rights reserved.
//

#import "MPRewardedVideoAdapter+Testing.h"

@implementation MPRewardedVideoAdapter (Testing)

@dynamic hasTrackedImpression;
@dynamic hasExpired;

@end
