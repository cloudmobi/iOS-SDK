//
//  MPMockMRAIDInterstitialViewController.h
//  MoPubSDK
//
//  Copyright © 2016 MoPub. All rights reserved.
//

#import "MPMRAIDInterstitialViewController.h"

@interface MPMockMRAIDInterstitialViewController : MPMRAIDInterstitialViewController
- (void)simulateDismiss;
- (void)simulateTap;
@end
