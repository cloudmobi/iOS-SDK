//
//  MPAdPlacerSharedExamplesSpec.h
//  MoPubSDK
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

extern NSString *aUICollectionAdPlacerThatWrapsItsDelegateAndDataSource;
extern NSString *aTwoArgumentDelegateOrDataSourceMethod;
extern NSString *aThreeArgumentDelegateOrDataSourceMethod;
extern NSString *aDelegateOrDataSourceMethod;
extern NSString *aDelegateOrDataSourceMethodThatReturnsAnObject;
extern NSString *aDelegateOrDataSourceMethodThatReturnsABOOL;
extern NSString *aDelegateOrDataSourceMethodThatReturnsAnNSInteger;
extern NSString *aSelectOrDeselectRowAtIndexPathMethod;
extern NSString *aDelegateOrDataSourceMethodThatContainsASelector;
