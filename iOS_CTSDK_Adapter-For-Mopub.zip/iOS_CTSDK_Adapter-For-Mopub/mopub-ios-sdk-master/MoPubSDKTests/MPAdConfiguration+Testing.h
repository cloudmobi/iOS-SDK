//
//  MPAdConfiguration+Testing.h
//  MoPubSDK
//
//  Copyright © 2017 MoPub. All rights reserved.
//

#import "MPAdConfiguration.h"

@interface MPAdConfiguration (Testing)

@property (nonatomic) NSInteger clickthroughExperimentBrowserAgent;

@end
