

#import <CTSDK/CTNativeAd.h>
@interface CTView : CTNativeAd
@property (nonatomic, strong)UIImageView *logoImage;
@property (nonatomic, strong)UILabel *titleLable;
@property (nonatomic, strong)UIImageView *iconImage;
@property (nonatomic, strong)UIImageView *imageImage;
@property (nonatomic, strong)UILabel *descLable;
@property (nonatomic, strong)UIButton *button;
@property (nonatomic, strong)UILabel *starLable;
@end
