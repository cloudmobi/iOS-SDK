//
//  RewardVideoViewController.h
//  CTSDK_iOS
//
//  Created by 兰旭平 on 2017/3/10.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RewardVideoViewController : UIViewController

@end
