#import "MPAdPositioning.h"
#import <Cedar/Cedar.h>

using namespace Cedar::Matchers;
using namespace Cedar::Doubles;

SPEC_BEGIN(MPAdPositioningSpec)

describe(@"MPAdPositioning", ^{
//    __block MPAdPositioning *model;

    beforeEach(^{

    });
});

SPEC_END
