//
//  NativeVideoTableViewController.m
//  CTSDK_iOS
//
//  Created by yeahmobi on 2018/3/9.
//  Copyright © 2018年 Mirinda. All rights reserved.
//

#import "NativeVideoMediaViewTableViewController.h"
#import "NativeVideoMediaViewTableViewCell.h"
#import "XCHudHelper.h"
#import "Tools.h"

@interface NativeVideoMediaViewTableViewController () <CTNativeVideoDelegate>
@property (nonatomic, assign) BOOL tableViewLoadFinish;
@property (nonatomic, strong) NSMutableArray* modelArray;
@end

@implementation NativeVideoMediaViewTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:[NativeVideoMediaViewTableViewCell class] forCellReuseIdentifier:@"NativeVideoCell"];
    
    self.modelArray = [[NSMutableArray alloc] init];
    
    for (int i = 0 ; i < 5 ; i++){
        [[CTService shareManager] getNativeVideoADswithSlotId:NativeVideoSlotId delegate:self imageWidthHightRate:CTImageWHRateOnePointNineToOne isTest:YES];
    }
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, XPWidth, kButtonHeight)];
    [self.tableView setTableHeaderView:headerView];
    
    UIButton *dismissBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, XPWidth, kButtonHeight)];
    dismissBtn.backgroundColor = [UIColor grayColor];
    [dismissBtn setTitle:@"Dismiss ViewController" forState:UIControlStateNormal];
    [dismissBtn addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    [headerView  addSubview:dismissBtn];
}

- (void)dismiss{
    [self dismissViewControllerAnimated:self completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - native video delegate
-(void)CTNativeVideoLoadSuccess:(CTNativeVideoModel *)nativeVideoModel{
    [self.modelArray addObject:nativeVideoModel];
    [self.tableView reloadData];
}

-(void)CTNativeVideoLoadFailed:(NSError *)error{
    NSString *errmsg = [[NSString alloc] initWithFormat:@"error no: %ld, err msg: %@", (long)error.code, error.domain];

    dispatch_async(dispatch_get_main_queue(), ^{
        [[XCHudHelper sharedInstance] showHudOnView:self.view caption:errmsg image:nil acitivity:NO autoHideTime:2.0f];
    });
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.modelArray count];
}

- (void)getImageFromURL:(NSString *)fileURL img:(void(^)(UIImage *ig))image
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        UIImage * result;
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
        result = [UIImage imageWithData:data];
        image(result);
    });
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NativeVideoMediaViewTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NativeVideoCell"];
    //数据
    CTNativeVideoModel * nativeVideoModel = [self.modelArray objectAtIndex:indexPath.row];
    [cell.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    cell.model = nativeVideoModel;
    cell.tableViewController = self;
    
    //label
    cell.nvTitleLable = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, self.view.frame.size.width, 25)];//标题
    cell.nvTitleLable.font = [UIFont systemFontOfSize:18];
    cell.nvTitleLable.textColor = [UIColor blackColor];
    cell.nvTitleLable.text = nativeVideoModel.title;
    [cell addSubview:cell.nvTitleLable];
    
    //desc
    cell.nvDescLable = [[UILabel alloc]initWithFrame:CGRectMake(25, [self getCellHeight] - 30, self.view.frame.size.width - 100, 30)];//标题
    cell.nvDescLable.font = [UIFont systemFontOfSize:12];
    cell.nvDescLable.textColor = [UIColor grayColor];
    cell.nvDescLable.text = nativeVideoModel.desc;
    [cell addSubview:cell.nvDescLable];
    
    //logo
    cell.nvLogo = [[UIImageView alloc]initWithFrame:CGRectMake(5, [self getCellHeight] - 25, 16, 16)];
    cell.nvLogo.image = nativeVideoModel.ADsignImage;
    [cell addSubview:cell.nvLogo];
    
    //media view width:height = 1.77:1
    cell.mediaView = [[CTMediaView alloc] initWithFrame:CGRectMake(0, 30, self.view.frame.size.width, self.view.frame.size.width/1.77)];
    cell.mediaView.autoplayEnabled = YES;
    cell.mediaView.WWANPlayEnabled = YES;
    [cell.mediaView setNativeVideoAd:nativeVideoModel];
    [cell addSubview:cell.mediaView];
    
    //download button view
    cell.nvBtnView = [UIButton buttonWithType:UIButtonTypeCustom];
    cell.nvBtnView.frame = CGRectMake(self.view.frame.size.width - 65, [self getCellHeight] - 25, 60, 20);
    cell.nvBtnView.layer.borderColor = [[UIColor blueColor] CGColor];
    cell.nvBtnView.layer.borderWidth = 1;
    cell.nvBtnView.layer.cornerRadius = 5;
    [cell addSubview:cell.nvBtnView];
    
    //download button label
    [cell.nvBtnView setTitle:nativeVideoModel.button forState:UIControlStateNormal];
    [cell.nvBtnView setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    cell.nvBtnView.titleLabel.font = [UIFont systemFontOfSize:12];
    
    //click gesture
    [cell addClickGesture];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [self getCellHeight];
}

- (CGFloat)getCellHeight{
    NSInteger titleHeight = 30;
    //视频比例1:1.77
    NSInteger movieViewHeight = self.view.frame.size.width / 1.77;
    NSInteger descHeight = 30;
    return titleHeight + movieViewHeight + descHeight;
}

@end
