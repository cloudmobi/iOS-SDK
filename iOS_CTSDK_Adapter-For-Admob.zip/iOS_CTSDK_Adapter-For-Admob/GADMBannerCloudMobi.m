//
//  GADMBannerCloudMobi.m
//  GPADMOB
//
//  Created by 兰旭平 on 2017/11/15.
//  Copyright © 2017年 MySDK.com. All rights reserved.
//

#import "GADMBannerCloudMobi.h"
#import <CTSDK/CTSDK.h>
@implementation GADMBannerCloudMobi
@synthesize delegate;

- (void)requestBannerAd:(GADAdSize)adSize parameter:(NSString * _Nullable)serverParameter label:(NSString * _Nullable)serverLabel request:(nonnull GADCustomEventRequest *)request {
    NSLog(@"request cloudmobi banner:%@ %@  %@",serverParameter,serverLabel,NSStringFromCGSize(adSize.size));
    CTADBannerSize ctSize;
    if (adSize.size.height == 100) {
        ctSize = CTADBannerSizeW320H100;
    } else if (adSize.size.height == 250) {
        ctSize = CTADBannerSizeW300H250;
    } else {
        ctSize = CTADBannerSizeW320H50;
    }
    [[CTService shareManager] loadRequestGetCTSDKConfigBySlot_id:serverParameter];
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
    [[CTService shareManager] getMRAIDBannerAdWithSlot:serverParameter delegate:self adSize:ctSize container:view isTest:NO];
}
//banner ad
- (void)CTAdViewDidRecieveBannerAd:(CTADMRAIDView*)adView {
    NSLog(@"cloudmobi banner : ok");
    [self.delegate customEventBanner:self didReceiveAd:adView];
}
//error while request ads.
- (void)CTAdView:(CTADMRAIDView*)adView didFailToReceiveAdWithError:(NSError*)error {
    NSLog(@"cloudmobi banner : error %@",error);
    [self.delegate customEventBanner:self didFailAd:error];
}
//jump to safari or internal webview
- (BOOL)CTAdView:(CTADMRAIDView*)adView shouldOpenURL:(NSURL*)url {
    [self.delegate customEventBannerWasClicked:self];
    [self.delegate customEventBannerWillPresentModal:self];
    [self.delegate customEventBannerDidDismissModal:self];
    return YES;
}
//will leave application
- (void)CTAdViewWillLeaveApplication:(CTADMRAIDView*)adView {
    [self.delegate customEventBannerWillLeaveApplication:self];
}
@end

