//
//  NativeVideoTableViewController.h
//  CTSDK_iOS
//
//  Created by yeahmobi on 2018/3/9.
//  Copyright © 2018年 Mirinda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NativeVideoMediaViewTableViewController : UITableViewController

@end
