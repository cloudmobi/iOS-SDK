//
//  InterstitialViewController.m
//  iOS-CTSDK-Demo
//
//  Created by 兰旭平 on 2016/12/27.
//  Copyright © 2016年 com.algorithms.lxp. All rights reserved.
//

#import "InterstitialViewController.h"
#import "Tools.h"
#import <CTSDK/CTService.h>
#import <CTSDK/CTADExternalDelegate.h>
@interface InterstitialViewController ()<CTAdViewDelegate>
@property (nonatomic, strong)ZCJHUD *hud;

@end

@implementation InterstitialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Interstitial";
    self.view.backgroundColor = [UIColor colorWithRed:248/255.0 green:248/255.0 blue:1 alpha:1];
    // Do any additional setup after loading the view.
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor colorWithRed:128/255.0 green:138/255.0 blue:135/255.0 alpha:1];
    button.frame = CGRectMake(0, XPHeight - 50, XPWidth/2.0, 50);
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTitle:[NSString stringWithFormat:@"RequestAd"] forState:UIControlStateNormal];
    [self.view addSubview:button];
    [button addTarget:self action:@selector(getCTInterstitia) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *showAD = [UIButton buttonWithType:UIButtonTypeCustom];
    showAD.backgroundColor = [UIColor colorWithRed:250/255.0 green:235/255.0 blue:215/255.0 alpha:1];
    showAD.frame = CGRectMake(XPWidth/2.0, XPHeight - 50, XPWidth/2.0, 50);
    [showAD setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [showAD setTitle:[NSString stringWithFormat:@"show"] forState:UIControlStateNormal];
    [self.view addSubview:showAD];
    [showAD addTarget:self action:@selector(showAdWithVC) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton* btn31 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn31.frame = CGRectMake(0, self.view.frame.size.height - 100, self.view.frame.size.width, 50);
    btn31.backgroundColor = [UIColor colorWithRed:255/255.0 green:165/255.0 blue:0 alpha:1];
    [btn31 setTitle:@"close" forState:UIControlStateNormal];
    [btn31 addTarget:self action:@selector(closeAdView) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn31];
}

-(void)closeAdView
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)getCTInterstitia
{
    [self showGetAdWithStr:@"request ad"];
    [[CTService shareManager] preloadMRAIDInterstitialAdWithSlotId:@"53479848" delegate:self isTest:YES];
}

- (void)showAdWithVC
{
    if ([[CTService shareManager] mraidInterstitialIsReady]){
        [[CTService shareManager] mraidInterstitialShow];
    }else
    {
        [self showGetAdWithStr:@"interstitial ad isn't ready"];
    }
}

- (void)done
{
    [self.hud hide];
}

- (void)showGetAdWithStr:(NSString *)str
{
    self.hud = [[ZCJHUD alloc] initWithView:self.view];
    [self.view addSubview:self.hud];
    self.hud.labelText = str;
    [self.hud show];
    [self performSelector:@selector(done) withObject:nil afterDelay:0.5];
}

#pragma mark - Delegate
- (void)CTAdViewDidRecieveInterstitialAd{
    if ([[CTService shareManager] mraidInterstitialIsReady]){
        [[CTService shareManager] mraidInterstitialShow];
    }else
    {
        [self showGetAdWithStr:@"interstitial ad isn't ready"];
    }
}

- (void)CTAdView:(CTADMRAIDView*)adView didFailToReceiveAdWithError:(NSError*)error
{
    NSLog(@"%@", [NSString stringWithFormat:@"Error:%@",error.description]);
    [self performSelector:@selector(done) withObject:nil afterDelay:0.5];
}

@end
