//
//  ALSInterstitialCustomEvent.h
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/10.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#if __has_include(<MoPub/MoPub.h>)
#import <MoPub/MoPub.h>
#else
#import "MPInterstitialCustomEvent.h"
#endif

@interface ALSInterstitialCustomEvent : MPInterstitialCustomEvent

@end
