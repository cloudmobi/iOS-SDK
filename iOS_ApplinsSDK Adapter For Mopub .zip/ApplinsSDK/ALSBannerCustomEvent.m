//
//  ALSBannerCustomEvent.m
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/7.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "ALSBannerCustomEvent.h"
#import <ApplinsSDK/Applins.h>
#import <ApplinsSDK/ALSADMRAIDView.h>

@interface ALSBannerCustomEvent()<ALSAdViewDelegate>
@property (nonatomic,strong)ALSADMRAIDView* mraidBanner;
@end

@implementation ALSBannerCustomEvent


- (BOOL)enableAutomaticImpressionAndClickTracking
{
    return NO;
}

- (void)requestAdWithSize:(CGSize)size customEventInfo:(NSDictionary *)info
{
    NSString *slotid = [info objectForKey:@"slotid"];
    ApplinsSDK *alsSDK = [ApplinsSDK shareSDK];
    [alsSDK initSDK:slotid];
    
    ALSBannerSize bannerSize;
    if (size.height > 25 && size.height <= 75)
    {
        bannerSize = ALSBannerSizeW320H50;
    }
    else if (size.height > 75 && size.height <= 175)
    {
        bannerSize = ALSBannerSizeW320H100;
    }
    else if (size.height > 175 && size.height < 300)
    {
        bannerSize = ALSBannerSizeW300H250;
    }
    else
    {
        NSError* error = [NSError errorWithDomain:@"No ad for input banner size." code:99999 userInfo:nil];
        if ([self.delegate respondsToSelector:@selector(bannerCustomEvent:didFailToLoadAdWithError:)])
        {
            [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:error];
        }
        return;
    }

    [alsSDK getBannerAD:slotid delegate:self adSize:bannerSize isTest:YES]; 
}

- (void)dealloc
{
    if (self.mraidBanner)
    {
        [self.mraidBanner removeFromSuperview];
    }
}

#pragma mark ALSAdViewDelegate methods

//banner ad
- (void)ALSLoadBannerSuccess:(ALSADMRAIDView*)adView {
    self.mraidBanner = adView;
    if ([self.delegate respondsToSelector:@selector(bannerCustomEvent:didLoadAd:)])
    {
        [self.delegate bannerCustomEvent:self didLoadAd:adView];
    }

    if ([self.delegate respondsToSelector:@selector(trackImpression)])
    {
        [self.delegate trackImpression];
    }
    
}

//error while request ads.
- (void)ALSAdView:(ALSADMRAIDView*)adView loadADFailedWithError:(NSError*)error {
    
    if ([self.delegate respondsToSelector:@selector(bannerCustomEvent:didFailToLoadAdWithError:)])
    {
        [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:error];
    }
}

//jump to safari or internal webview
- (BOOL)ALSAdView:(ALSADMRAIDView*)adView shouldOpenURL:(NSURL*)url {
    if ([self.delegate respondsToSelector:@selector(trackClick)])
    {
        [self.delegate trackClick];
    }
    return YES;
}

//will leave application
- (void)ALSAdViewWillLeaveApplication:(ALSADMRAIDView*)adView {
    
    if ([self.delegate respondsToSelector:@selector(bannerCustomEventWillLeaveApplication:)])
    {
        [self.delegate bannerCustomEventWillLeaveApplication:self];
    }
}

@end
