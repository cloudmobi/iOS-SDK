//
//  Tools.m
//  iOS-CTSDK-Demo
//
//  Created by 兰旭平 on 2016/12/27.
//  Copyright © 2016年 com.algorithms.lxp. All rights reserved.
//

#import "Tools.h"

@implementation Tools

- (void)done
{
    [self.hud hide];
}
- (void)showGetAd
{
    /*
    self.hud = [[ZCJHUD alloc] initWithView:self.view];
    [self.view addSubview:self.hud];
    self.hud.labelText = @"点击按钮，正在加载！";
    [self.hud show];
    [self performSelector:@selector(done) withObject:nil afterDelay:0.5];
     */
}


@end
