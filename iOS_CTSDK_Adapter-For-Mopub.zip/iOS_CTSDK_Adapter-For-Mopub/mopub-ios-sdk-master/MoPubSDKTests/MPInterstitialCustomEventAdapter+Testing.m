//
//  MPInterstitialCustomEventAdapter+Testing.m
//  MoPubSDK
//
//  Copyright © 2017 MoPub. All rights reserved.
//

#import "MPInterstitialCustomEventAdapter+Testing.h"

@implementation MPInterstitialCustomEventAdapter (Testing)

@dynamic hasTrackedImpression;

@end
