//
//  BannerViewController.m
//  iOS-CTSDK-Demo
//
//  Created by 兰旭平 on 2016/12/27.
//  Copyright © 2016年 com.algorithms.lxp. All rights reserved.
//

#import "BannerViewController.h"
#import "Tools.h"
#import <CTSDK/CTService.h>
#import <CTSDK/CTADExternalDelegate.h>
@interface BannerViewController ()<CTAdViewDelegate>
@property (nonatomic, strong)ZCJHUD *hud;
@property (nonatomic, assign)CTADBannerSize bannerSize;
@property (nonatomic, strong)CTADMRAIDView *mraidAdView;
@end

@implementation BannerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Banner";
    self.view.backgroundColor = [UIColor colorWithRed:248/255.0 green:248/255.0 blue:1 alpha:1];
    // Do any additional setup after loading the view.
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor colorWithRed:115/255.0 green:74/255.0 blue:18/255.0 alpha:1];
    button.frame = CGRectMake(0, self.view.frame.size.height - 50, self.view.frame.size.width , 50);
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTitle:[NSString stringWithFormat:@"RequestAd"] forState:UIControlStateNormal];
    [self.view addSubview:button];
    
    [button addTarget:self action:@selector(getCTBanner) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton* btn31 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn31.frame = CGRectMake(0, self.view.frame.size.height - 100, self.view.frame.size.width, 50);
    btn31.backgroundColor = [UIColor colorWithRed:255/255.0 green:165/255.0 blue:0 alpha:1];
    [btn31 setTitle:@"close" forState:UIControlStateNormal];
    [btn31 addTarget:self action:@selector(closeAdView) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn31];
}

-(void)closeAdView
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)getCTBanner
{
    [self showGetAdWithStr:@"request ad"];
    //random request banner for different sizes
    int x = arc4random() % 100;
    if (x <= 33)
        self.bannerSize = CTADBannerSizeW320H50;
    else if (x > 33 && x<= 66)
        self.bannerSize = CTADBannerSizeW320H100;
    else
        self.bannerSize = CTADBannerSizeW300H250;
    
    [[CTService shareManager] getMRAIDBannerAdWithSlot:bannerSlotId delegate:self adSize:self.bannerSize container:self.view isTest:NO];
}

#pragma mark delegate
- (void)CTAdViewDidRecieveBannerAd:(CTADMRAIDView*)adView
{
    if(adView == nil)
        return;

    [self.mraidAdView removeFromSuperview];
    self.mraidAdView = adView;
    
    if(self.bannerSize == CTADBannerSizeW320H50)
        self.mraidAdView.frame = CGRectMake(0, 0, 320, 50);
    else if(self.bannerSize == CTADBannerSizeW320H100)
        self.mraidAdView.frame = CGRectMake(0, 0, 320, 100);
    else if(self.bannerSize == CTADBannerSizeW300H250)
        self.mraidAdView.frame = CGRectMake(0, 0, 300, 250);
    self.mraidAdView.center = self.view.center;
    [self.view addSubview:self.mraidAdView];
}

- (void)CTAdView:(CTADMRAIDView*)adView didFailToReceiveAdWithError:(NSError*)error
{
    NSLog(@"%@", [NSString stringWithFormat:@"Error:%@",error.description]);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)done
{
    [self.hud hide];
}
- (void)showGetAdWithStr:(NSString *)str
{
    self.hud = [[ZCJHUD alloc] initWithView:self.view];
    [self.view addSubview:self.hud];
    self.hud.labelText = str;
    [self.hud show];
    [self performSelector:@selector(done) withObject:nil afterDelay:0.5];
}

#pragma mark - Delegate


@end
