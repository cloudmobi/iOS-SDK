//
//  XCTestCase+MPAddition.h
//  MoPubSDK
//
//  Copyright © 2017 MoPub. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface XCTestCase (MPAddition)

- (NSData *)dataFromXMLFileNamed:(NSString *)name class:(Class)aClass;

@end
