//
//  ALSNativeAdAdapter.h
//  GoldMedal
//
//  Created by Mirinda on 17/7/10.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#if __has_include(<MoPub / MoPub.h>)
#import <MoPub/MoPub.h>
#else
#import "MPNativeAdAdapter.h"
#endif

#import <Foundation/Foundation.h>
#import <ApplinsSDK/Applins.h>

@interface ALSNativeAdAdapter : NSObject<MPNativeAdAdapter,ALSNativeAdDelegate>

@property(nonatomic, weak) id<MPNativeAdAdapterDelegate> delegate;
@property(nonatomic, strong) ALSNativeAdModel *nativeAd;
- (instancetype)initWithALSNativeAd:(ALSNativeAdModel*)ALSNativeAd;

@end
